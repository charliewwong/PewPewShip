﻿namespace Final_Project___Charlie_Wong
{
    partial class FrmGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.obstacle = new System.Windows.Forms.Label();
            this.ObstacleMover = new System.Windows.Forms.Timer(this.components);
            this.obstacle2 = new System.Windows.Forms.Label();
            this.Obstacle2Mover = new System.Windows.Forms.Timer(this.components);
            this.Ground = new System.Windows.Forms.Label();
            this.obstacle3 = new System.Windows.Forms.Label();
            this.Obstacle3Mover = new System.Windows.Forms.Timer(this.components);
            this.LaserMoveToUserPosition = new System.Windows.Forms.Timer(this.components);
            this.obstacle4 = new System.Windows.Forms.Label();
            this.Obstacle4Mover = new System.Windows.Forms.Timer(this.components);
            this.obstacle5 = new System.Windows.Forms.Label();
            this.Obstacle5Mover = new System.Windows.Forms.Timer(this.components);
            this.obstacle6 = new System.Windows.Forms.Label();
            this.Obstacle6Mover = new System.Windows.Forms.Timer(this.components);
            this.obstacle7 = new System.Windows.Forms.Label();
            this.Obstacle7Mover = new System.Windows.Forms.Timer(this.components);
            this.obstacle8 = new System.Windows.Forms.Label();
            this.Obstacle8Mover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShipMover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShotMover = new System.Windows.Forms.Timer(this.components);
            this.Collisions = new System.Windows.Forms.Timer(this.components);
            this.LblUserScore = new System.Windows.Forms.Label();
            this.LblUserHealth = new System.Windows.Forms.Label();
            this.EnemyShip2Mover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShot2Mover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShip3Mover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShot3Mover = new System.Windows.Forms.Timer(this.components);
            this.UserScoreTitle = new System.Windows.Forms.Label();
            this.UserHealthTitle = new System.Windows.Forms.Label();
            this.EnemyShip3Shot = new System.Windows.Forms.PictureBox();
            this.EnemyShip3Firing = new System.Windows.Forms.PictureBox();
            this.EnemyShip3 = new System.Windows.Forms.PictureBox();
            this.EnemyShip2Firing = new System.Windows.Forms.PictureBox();
            this.EnemyShip2Shot = new System.Windows.Forms.PictureBox();
            this.EnemyShip2 = new System.Windows.Forms.PictureBox();
            this.UserShip = new System.Windows.Forms.PictureBox();
            this.EnemyShipShot = new System.Windows.Forms.PictureBox();
            this.EnemyShipFiring = new System.Windows.Forms.PictureBox();
            this.EnemyShip = new System.Windows.Forms.PictureBox();
            this.UserShipLaser = new System.Windows.Forms.PictureBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.LblKillCount = new System.Windows.Forms.Label();
            this.KillCountTitle = new System.Windows.Forms.Label();
            this.EndTitle = new System.Windows.Forms.Label();
            this.EndTitleTitle = new System.Windows.Forms.Label();
            this.LblReturn = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3Shot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3Firing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2Firing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2Shot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserShip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShipShot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShipFiring)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserShipLaser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // obstacle
            // 
            this.obstacle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle.Location = new System.Drawing.Point(1113, 449);
            this.obstacle.Name = "obstacle";
            this.obstacle.Size = new System.Drawing.Size(141, 271);
            this.obstacle.TabIndex = 0;
            this.obstacle.Text = "label1";
            this.obstacle.Click += new System.EventHandler(this.obstacle_Click);
            // 
            // ObstacleMover
            // 
            this.ObstacleMover.Enabled = true;
            this.ObstacleMover.Interval = 50;
            this.ObstacleMover.Tick += new System.EventHandler(this.ObstacleMover_Tick);
            // 
            // obstacle2
            // 
            this.obstacle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle2.Location = new System.Drawing.Point(1326, 493);
            this.obstacle2.Name = "obstacle2";
            this.obstacle2.Size = new System.Drawing.Size(160, 227);
            this.obstacle2.TabIndex = 1;
            this.obstacle2.Text = "label1";
            // 
            // Obstacle2Mover
            // 
            this.Obstacle2Mover.Enabled = true;
            this.Obstacle2Mover.Interval = 50;
            this.Obstacle2Mover.Tick += new System.EventHandler(this.Obstacle2Mover_Tick);
            // 
            // Ground
            // 
            this.Ground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Ground.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.Ground.Location = new System.Drawing.Point(3, 242);
            this.Ground.Name = "Ground";
            this.Ground.Size = new System.Drawing.Size(1550, 118);
            this.Ground.TabIndex = 2;
            this.Ground.Text = "label1";
            // 
            // obstacle3
            // 
            this.obstacle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle3.Location = new System.Drawing.Point(903, 449);
            this.obstacle3.Name = "obstacle3";
            this.obstacle3.Size = new System.Drawing.Size(158, 271);
            this.obstacle3.TabIndex = 3;
            this.obstacle3.Text = "label1";
            // 
            // Obstacle3Mover
            // 
            this.Obstacle3Mover.Enabled = true;
            this.Obstacle3Mover.Interval = 50;
            this.Obstacle3Mover.Tick += new System.EventHandler(this.Obstacle3Mover_Tick);
            // 
            // LaserMoveToUserPosition
            // 
            this.LaserMoveToUserPosition.Enabled = true;
            this.LaserMoveToUserPosition.Interval = 10;
            this.LaserMoveToUserPosition.Tick += new System.EventHandler(this.LaserMoveToUserPosition_Tick);
            // 
            // obstacle4
            // 
            this.obstacle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle4.Location = new System.Drawing.Point(685, 477);
            this.obstacle4.Name = "obstacle4";
            this.obstacle4.Size = new System.Drawing.Size(158, 207);
            this.obstacle4.TabIndex = 5;
            this.obstacle4.Text = "label1";
            // 
            // Obstacle4Mover
            // 
            this.Obstacle4Mover.Enabled = true;
            this.Obstacle4Mover.Interval = 50;
            this.Obstacle4Mover.Tick += new System.EventHandler(this.Obstacle4Mover_Tick);
            // 
            // obstacle5
            // 
            this.obstacle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle5.Location = new System.Drawing.Point(534, 477);
            this.obstacle5.Name = "obstacle5";
            this.obstacle5.Size = new System.Drawing.Size(112, 207);
            this.obstacle5.TabIndex = 6;
            this.obstacle5.Text = "label1";
            // 
            // Obstacle5Mover
            // 
            this.Obstacle5Mover.Enabled = true;
            this.Obstacle5Mover.Interval = 50;
            this.Obstacle5Mover.Tick += new System.EventHandler(this.Obstacle5Mover_Tick);
            // 
            // obstacle6
            // 
            this.obstacle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle6.Location = new System.Drawing.Point(401, 502);
            this.obstacle6.Name = "obstacle6";
            this.obstacle6.Size = new System.Drawing.Size(100, 209);
            this.obstacle6.TabIndex = 7;
            this.obstacle6.Text = "label1";
            // 
            // Obstacle6Mover
            // 
            this.Obstacle6Mover.Enabled = true;
            this.Obstacle6Mover.Interval = 50;
            this.Obstacle6Mover.Tick += new System.EventHandler(this.Obstacle6Mover_Tick);
            // 
            // obstacle7
            // 
            this.obstacle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle7.Location = new System.Drawing.Point(252, 513);
            this.obstacle7.Name = "obstacle7";
            this.obstacle7.Size = new System.Drawing.Size(100, 198);
            this.obstacle7.TabIndex = 8;
            this.obstacle7.Text = "label1";
            // 
            // Obstacle7Mover
            // 
            this.Obstacle7Mover.Enabled = true;
            this.Obstacle7Mover.Interval = 50;
            this.Obstacle7Mover.Tick += new System.EventHandler(this.Obstacle7Mover_Tick);
            // 
            // obstacle8
            // 
            this.obstacle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.obstacle8.Location = new System.Drawing.Point(77, 493);
            this.obstacle8.Name = "obstacle8";
            this.obstacle8.Size = new System.Drawing.Size(93, 206);
            this.obstacle8.TabIndex = 9;
            this.obstacle8.Text = "label1";
            // 
            // Obstacle8Mover
            // 
            this.Obstacle8Mover.Enabled = true;
            this.Obstacle8Mover.Interval = 50;
            this.Obstacle8Mover.Tick += new System.EventHandler(this.Obstacle8Mover_Tick);
            // 
            // EnemyShipMover
            // 
            this.EnemyShipMover.Enabled = true;
            this.EnemyShipMover.Interval = 20;
            this.EnemyShipMover.Tick += new System.EventHandler(this.EnemyShipMover_Tick);
            // 
            // EnemyShotMover
            // 
            this.EnemyShotMover.Enabled = true;
            this.EnemyShotMover.Interval = 10;
            this.EnemyShotMover.Tick += new System.EventHandler(this.EnemyShotMover_Tick);
            // 
            // Collisions
            // 
            this.Collisions.Enabled = true;
            this.Collisions.Tick += new System.EventHandler(this.Collisions_Tick);
            // 
            // LblUserScore
            // 
            this.LblUserScore.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LblUserScore.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblUserScore.Location = new System.Drawing.Point(1116, 374);
            this.LblUserScore.Name = "LblUserScore";
            this.LblUserScore.Size = new System.Drawing.Size(138, 62);
            this.LblUserScore.TabIndex = 14;
            this.LblUserScore.Text = "label1";
            this.LblUserScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LblUserScore.Click += new System.EventHandler(this.LblUserScore_Click);
            // 
            // LblUserHealth
            // 
            this.LblUserHealth.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LblUserHealth.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblUserHealth.Location = new System.Drawing.Point(923, 374);
            this.LblUserHealth.Name = "LblUserHealth";
            this.LblUserHealth.Size = new System.Drawing.Size(138, 62);
            this.LblUserHealth.TabIndex = 15;
            this.LblUserHealth.Text = "label1";
            this.LblUserHealth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EnemyShip2Mover
            // 
            this.EnemyShip2Mover.Enabled = true;
            this.EnemyShip2Mover.Interval = 20;
            this.EnemyShip2Mover.Tick += new System.EventHandler(this.EnemyShip2Mover_Tick);
            // 
            // EnemyShot2Mover
            // 
            this.EnemyShot2Mover.Enabled = true;
            this.EnemyShot2Mover.Interval = 10;
            this.EnemyShot2Mover.Tick += new System.EventHandler(this.EnemyShot2Mover_Tick);
            // 
            // EnemyShip3Mover
            // 
            this.EnemyShip3Mover.Enabled = true;
            this.EnemyShip3Mover.Interval = 20;
            this.EnemyShip3Mover.Tick += new System.EventHandler(this.EnemyShip3Mover_Tick);
            // 
            // EnemyShot3Mover
            // 
            this.EnemyShot3Mover.Enabled = true;
            this.EnemyShot3Mover.Interval = 10;
            this.EnemyShot3Mover.Tick += new System.EventHandler(this.EnemyShot3Mover_Tick);
            // 
            // UserScoreTitle
            // 
            this.UserScoreTitle.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UserScoreTitle.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserScoreTitle.Location = new System.Drawing.Point(1116, 339);
            this.UserScoreTitle.Name = "UserScoreTitle";
            this.UserScoreTitle.Size = new System.Drawing.Size(138, 35);
            this.UserScoreTitle.TabIndex = 22;
            this.UserScoreTitle.Text = "User Score:";
            this.UserScoreTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UserHealthTitle
            // 
            this.UserHealthTitle.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UserHealthTitle.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserHealthTitle.Location = new System.Drawing.Point(923, 339);
            this.UserHealthTitle.Name = "UserHealthTitle";
            this.UserHealthTitle.Size = new System.Drawing.Size(138, 35);
            this.UserHealthTitle.TabIndex = 23;
            this.UserHealthTitle.Text = "User Health:";
            this.UserHealthTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EnemyShip3Shot
            // 
            this.EnemyShip3Shot.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipShot1;
            this.EnemyShip3Shot.Location = new System.Drawing.Point(906, 242);
            this.EnemyShip3Shot.Name = "EnemyShip3Shot";
            this.EnemyShip3Shot.Size = new System.Drawing.Size(100, 27);
            this.EnemyShip3Shot.TabIndex = 21;
            this.EnemyShip3Shot.TabStop = false;
            // 
            // EnemyShip3Firing
            // 
            this.EnemyShip3Firing.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipFiring1;
            this.EnemyShip3Firing.Location = new System.Drawing.Point(853, 297);
            this.EnemyShip3Firing.Name = "EnemyShip3Firing";
            this.EnemyShip3Firing.Size = new System.Drawing.Size(191, 50);
            this.EnemyShip3Firing.TabIndex = 20;
            this.EnemyShip3Firing.TabStop = false;
            // 
            // EnemyShip3
            // 
            this.EnemyShip3.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShip1;
            this.EnemyShip3.Location = new System.Drawing.Point(558, 230);
            this.EnemyShip3.Name = "EnemyShip3";
            this.EnemyShip3.Size = new System.Drawing.Size(251, 145);
            this.EnemyShip3.TabIndex = 19;
            this.EnemyShip3.TabStop = false;
            // 
            // EnemyShip2Firing
            // 
            this.EnemyShip2Firing.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipFiring1;
            this.EnemyShip2Firing.Location = new System.Drawing.Point(853, 52);
            this.EnemyShip2Firing.Name = "EnemyShip2Firing";
            this.EnemyShip2Firing.Size = new System.Drawing.Size(191, 53);
            this.EnemyShip2Firing.TabIndex = 18;
            this.EnemyShip2Firing.TabStop = false;
            // 
            // EnemyShip2Shot
            // 
            this.EnemyShip2Shot.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipShot1;
            this.EnemyShip2Shot.Location = new System.Drawing.Point(730, 52);
            this.EnemyShip2Shot.Name = "EnemyShip2Shot";
            this.EnemyShip2Shot.Size = new System.Drawing.Size(99, 27);
            this.EnemyShip2Shot.TabIndex = 17;
            this.EnemyShip2Shot.TabStop = false;
            // 
            // EnemyShip2
            // 
            this.EnemyShip2.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShip1;
            this.EnemyShip2.Location = new System.Drawing.Point(268, 229);
            this.EnemyShip2.Name = "EnemyShip2";
            this.EnemyShip2.Size = new System.Drawing.Size(251, 146);
            this.EnemyShip2.TabIndex = 16;
            this.EnemyShip2.TabStop = false;
            // 
            // UserShip
            // 
            this.UserShip.BackColor = System.Drawing.Color.Transparent;
            this.UserShip.Image = global::Final_Project___Charlie_Wong.Properties.Resources.UserShip1;
            this.UserShip.Location = new System.Drawing.Point(195, 78);
            this.UserShip.Name = "UserShip";
            this.UserShip.Size = new System.Drawing.Size(427, 128);
            this.UserShip.TabIndex = 13;
            this.UserShip.TabStop = false;
            // 
            // EnemyShipShot
            // 
            this.EnemyShipShot.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipShot1;
            this.EnemyShipShot.Location = new System.Drawing.Point(743, 105);
            this.EnemyShipShot.Name = "EnemyShipShot";
            this.EnemyShipShot.Size = new System.Drawing.Size(100, 27);
            this.EnemyShipShot.TabIndex = 12;
            this.EnemyShipShot.TabStop = false;
            // 
            // EnemyShipFiring
            // 
            this.EnemyShipFiring.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShipFiring1;
            this.EnemyShipFiring.Location = new System.Drawing.Point(1039, 129);
            this.EnemyShipFiring.Name = "EnemyShipFiring";
            this.EnemyShipFiring.Size = new System.Drawing.Size(191, 61);
            this.EnemyShipFiring.TabIndex = 11;
            this.EnemyShipFiring.TabStop = false;
            // 
            // EnemyShip
            // 
            this.EnemyShip.BackColor = System.Drawing.Color.Transparent;
            this.EnemyShip.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShip1;
            this.EnemyShip.Location = new System.Drawing.Point(1236, 52);
            this.EnemyShip.Name = "EnemyShip";
            this.EnemyShip.Size = new System.Drawing.Size(250, 154);
            this.EnemyShip.TabIndex = 10;
            this.EnemyShip.TabStop = false;
            // 
            // UserShipLaser
            // 
            this.UserShipLaser.BackColor = System.Drawing.Color.Transparent;
            this.UserShipLaser.Image = global::Final_Project___Charlie_Wong.Properties.Resources.UserShipLaser;
            this.UserShipLaser.Location = new System.Drawing.Point(465, 138);
            this.UserShipLaser.Name = "UserShipLaser";
            this.UserShipLaser.Size = new System.Drawing.Size(529, 52);
            this.UserShipLaser.TabIndex = 4;
            this.UserShipLaser.TabStop = false;
            // 
            // LblKillCount
            // 
            this.LblKillCount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.LblKillCount.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblKillCount.Location = new System.Drawing.Point(736, 374);
            this.LblKillCount.Name = "LblKillCount";
            this.LblKillCount.Size = new System.Drawing.Size(138, 62);
            this.LblKillCount.TabIndex = 24;
            this.LblKillCount.Text = "label1";
            this.LblKillCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // KillCountTitle
            // 
            this.KillCountTitle.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.KillCountTitle.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KillCountTitle.Location = new System.Drawing.Point(736, 340);
            this.KillCountTitle.Name = "KillCountTitle";
            this.KillCountTitle.Size = new System.Drawing.Size(138, 35);
            this.KillCountTitle.TabIndex = 25;
            this.KillCountTitle.Text = "Enemies Killed:";
            this.KillCountTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EndTitle
            // 
            this.EndTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.EndTitle.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndTitle.Location = new System.Drawing.Point(65, 297);
            this.EndTitle.Name = "EndTitle";
            this.EndTitle.Size = new System.Drawing.Size(431, 251);
            this.EndTitle.TabIndex = 26;
            this.EndTitle.Text = "Yes";
            this.EndTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EndTitleTitle
            // 
            this.EndTitleTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.EndTitleTitle.Font = new System.Drawing.Font("Comic Sans MS", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndTitleTitle.Location = new System.Drawing.Point(65, 242);
            this.EndTitleTitle.Name = "EndTitleTitle";
            this.EndTitleTitle.Size = new System.Drawing.Size(431, 55);
            this.EndTitleTitle.TabIndex = 27;
            this.EndTitleTitle.Text = "YOU DIED, with a score of:";
            this.EndTitleTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblReturn
            // 
            this.LblReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.LblReturn.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblReturn.Location = new System.Drawing.Point(66, 156);
            this.LblReturn.Name = "LblReturn";
            this.LblReturn.Size = new System.Drawing.Size(430, 86);
            this.LblReturn.TabIndex = 28;
            this.LblReturn.Text = "Click here to return to the title screen...";
            this.LblReturn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.LblReturn.Click += new System.EventHandler(this.label1_Click);
            // 
            // FrmGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1552, 693);
            this.Controls.Add(this.LblReturn);
            this.Controls.Add(this.EndTitleTitle);
            this.Controls.Add(this.EndTitle);
            this.Controls.Add(this.KillCountTitle);
            this.Controls.Add(this.LblKillCount);
            this.Controls.Add(this.UserHealthTitle);
            this.Controls.Add(this.UserScoreTitle);
            this.Controls.Add(this.EnemyShip3Shot);
            this.Controls.Add(this.EnemyShip3Firing);
            this.Controls.Add(this.EnemyShip3);
            this.Controls.Add(this.EnemyShip2Firing);
            this.Controls.Add(this.EnemyShip2Shot);
            this.Controls.Add(this.EnemyShip2);
            this.Controls.Add(this.LblUserHealth);
            this.Controls.Add(this.LblUserScore);
            this.Controls.Add(this.UserShip);
            this.Controls.Add(this.EnemyShipShot);
            this.Controls.Add(this.EnemyShipFiring);
            this.Controls.Add(this.EnemyShip);
            this.Controls.Add(this.obstacle8);
            this.Controls.Add(this.obstacle7);
            this.Controls.Add(this.obstacle6);
            this.Controls.Add(this.obstacle5);
            this.Controls.Add(this.obstacle4);
            this.Controls.Add(this.UserShipLaser);
            this.Controls.Add(this.obstacle3);
            this.Controls.Add(this.Ground);
            this.Controls.Add(this.obstacle2);
            this.Controls.Add(this.obstacle);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "FrmGame";
            this.Text = "FrmGame";
            this.Load += new System.EventHandler(this.FrmGame_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FrmGame_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmGame_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3Shot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3Firing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2Firing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2Shot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserShip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShipShot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShipFiring)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UserShipLaser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label obstacle;
        private System.Windows.Forms.Timer ObstacleMover;
        private System.Windows.Forms.Label obstacle2;
        private System.Windows.Forms.Timer Obstacle2Mover;
        private System.Windows.Forms.Label Ground;
        private System.Windows.Forms.Label obstacle3;
        private System.Windows.Forms.Timer Obstacle3Mover;
        private System.Windows.Forms.PictureBox UserShipLaser;
        private System.Windows.Forms.Timer LaserMoveToUserPosition;
        private System.Windows.Forms.Label obstacle4;
        private System.Windows.Forms.Timer Obstacle4Mover;
        private System.Windows.Forms.Label obstacle5;
        private System.Windows.Forms.Timer Obstacle5Mover;
        private System.Windows.Forms.Label obstacle6;
        private System.Windows.Forms.Timer Obstacle6Mover;
        private System.Windows.Forms.Label obstacle7;
        private System.Windows.Forms.Timer Obstacle7Mover;
        private System.Windows.Forms.Label obstacle8;
        private System.Windows.Forms.Timer Obstacle8Mover;
        private System.Windows.Forms.PictureBox EnemyShip;
        private System.Windows.Forms.Timer EnemyShipMover;
        private System.Windows.Forms.PictureBox EnemyShipFiring;
        private System.Windows.Forms.PictureBox EnemyShipShot;
        private System.Windows.Forms.Timer EnemyShotMover;
        private System.Windows.Forms.Timer Collisions;
        private System.Windows.Forms.PictureBox UserShip;
        private System.Windows.Forms.Label LblUserScore;
        private System.Windows.Forms.Label LblUserHealth;
        private System.Windows.Forms.PictureBox EnemyShip2;
        private System.Windows.Forms.PictureBox EnemyShip2Shot;
        private System.Windows.Forms.PictureBox EnemyShip2Firing;
        private System.Windows.Forms.Timer EnemyShip2Mover;
        private System.Windows.Forms.Timer EnemyShot2Mover;
        private System.Windows.Forms.PictureBox EnemyShip3;
        private System.Windows.Forms.PictureBox EnemyShip3Firing;
        private System.Windows.Forms.PictureBox EnemyShip3Shot;
        private System.Windows.Forms.Timer EnemyShip3Mover;
        private System.Windows.Forms.Timer EnemyShot3Mover;
        private System.Windows.Forms.Label UserScoreTitle;
        private System.Windows.Forms.Label UserHealthTitle;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label LblKillCount;
        private System.Windows.Forms.Label KillCountTitle;
        private System.Windows.Forms.Label EndTitle;
        private System.Windows.Forms.Label EndTitleTitle;
        private System.Windows.Forms.Label LblReturn;
    }
}