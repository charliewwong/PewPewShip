﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;




namespace Final_Project___Charlie_Wong
{
    public partial class FrmGame : Form
    {
        //image data
        Image imgUserShot = Properties.Resources.UserShipShot1;

        //ints used to find location of user ship for user shot
        int curShotX = 500;
        int curShotY = 300;

        //user's score, health, and kill count
        int userHealth = 500;
        int userScore = 0;
        int killCount = 0;

        //enemy ships' health
        int enemyShipHealth = 25;
        int enemyShip2Health = 25;
        int enemyShip3Health = 25;

        //for playing sound effects
        SoundPlayer spUser = new SoundPlayer(Properties.Resources.WilhelmScream);
        SoundPlayer spEnemy = new SoundPlayer(Properties.Resources.UserDed); //Note: the sample is called UserDed, however it was used for when the enemy lost all health

        //random
        Random randy = new Random();

        public FrmGame()
        {
            InitializeComponent();
            //full screen
            this.WindowState = FormWindowState.Maximized;

            //setting location of all obstacles, one after the other
            obstacle.Location = new Point(this.Width,this.Height-200);
            obstacle2.Location = new Point(this.Width + 200, this.Height - 100);
            obstacle3.Location = new Point(this.Width + 400, this.Height - 200);
            obstacle4.Location = new Point(this.Width + 600, this.Height - 100);
            obstacle5.Location = new Point(this.Width + 800, this.Height - 200);
            obstacle6.Location = new Point(this.Width + 1000, this.Height - 100);
            obstacle7.Location = new Point(this.Width + 1200, this.Height - 200);
            obstacle8.Location = new Point(this.Width + 1400, this.Height - 100);

            //setting ground location to be bottom of screen
            Ground.Location = new Point(0, this.Height);
            Ground.Width = this.Width + 1000;
            Ground.Height = 1000;

            //starting point of enemy ships
            EnemyShip.Location = new Point(this.Width + 400, 50); //MAYBE ADD SOUND EFFECT WHEN SHIP IS DED // add ending screen //theme music
            EnemyShip2.Location = new Point(this.Width + 500, 300);
            EnemyShip3.Location = new Point(this.Width + 600, 175);

            //starting point of user ship
            UserShip.Location = new Point(100, this.Height -500);

            //setting location of user's health count, kill count, and score
            LblUserScore.Location = new Point(this.Width - 100, this.Height + 120);
            LblUserHealth.Location = new Point(this.Width - 300, this.Height + 120);
            LblKillCount.Location = new Point(this.Width -500, this.Height + 120);
            UserScoreTitle.Location = new Point(this.Width - 100, this.Height + 85);
            UserHealthTitle.Location = new Point(this.Width - 300, this.Height + 85);
            KillCountTitle.Location = new Point(this.Width -500, this.Height + 85);

            //moving game over display off screen until needed
            EndTitle.Location = new Point(this.Width + 1000, this.Height + 1000);
            EndTitleTitle.Location = new Point(this.Width + 1000, this.Height + 1000);
            LblReturn.Location = new Point(this.Width + 1000, this.Height + 1000);

        }

        private void FrmGame_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //drawing image of user shot
            g.DrawImage(imgUserShot, curShotX, curShotY);

        }
        
        private void FrmGame_KeyDown(object sender, KeyEventArgs e)
        {
            //user controls: moves ship up, down, left "backwards", right "forwards"
            switch (e.KeyCode)
            {
                case Keys.Up:
                    curShotY -= 15;
                    UserShip.Location = new Point(UserShip.Location.X, UserShip.Location.Y - 15);
                    break;

                case Keys.Down:
                    curShotY += 15;
                    UserShip.Location = new Point(UserShip.Location.X, UserShip.Location.Y + 15);
                    break;
                    
                case Keys.Left:
                    curShotX -= 10;
                    UserShip.Location = new Point(UserShip.Location.X - 10, UserShip.Location.Y);
                    break;
                    
                case Keys.Right:
                    curShotX += 20;
                    UserShip.Location = new Point(UserShip.Location.X + 20, UserShip.Location.Y);
                    break;
 
            }

            this.Invalidate();
        }


        private void ObstacleMover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacleHeight = randy.Next(250, 1000);
            int obstacleWidth = randy.Next(10, 1000);

            obstacle.Location = new Point(obstacle.Location.X - 10, obstacle.Location.Y);
            if(obstacle.Location.X < -700)
            {
                obstacle.Height = obstacleHeight;
                obstacle.Width = obstacleWidth;

                obstacle.Location = new Point(this.Width, obstacle.Location.Y);
                
            }
           
        }
        private void Obstacle2Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle2Height = randy.Next(this.Width - 200, this.Width-100);
            int obstacle2Width = randy.Next(10, 1000);

            obstacle2.Location = new Point(obstacle2.Location.X - 10, obstacle2.Location.Y);
            if (obstacle2.Location.X < -700)
            {
                obstacle2.Height = obstacle2Height;
                obstacle2.Width = obstacle2Width;

                obstacle2.Location = new Point(this.Width , obstacle2.Location.Y);

            }
        }
        private void Obstacle3Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle3Height = randy.Next(this.Width - 400, this.Width - 200);
            int obstacle3Width = randy.Next(10, 1000);

            obstacle3.Location = new Point(obstacle3.Location.X - 10, obstacle3.Location.Y);
            if (obstacle3.Location.X < -700)
            {
                obstacle3.Height = obstacle3Height;
                obstacle3.Width = obstacle3Width;

                obstacle3.Location = new Point(this.Width, obstacle3.Location.Y);

            }
        }
        private void Obstacle4Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle4Height = randy.Next(this.Width - 600, this.Width - 100);
            int obstacle4Width = randy.Next(10, 1000);

            obstacle4.Location = new Point(obstacle4.Location.X - 10, obstacle4.Location.Y);
            if (obstacle4.Location.X < -700)
            {
                obstacle4.Height = obstacle4Height;
                obstacle4.Width = obstacle4Width;

                obstacle4.Location = new Point(this.Width, obstacle4.Location.Y);

            }
        }
        private void Obstacle5Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle5Height = randy.Next(this.Width - 800, this.Width - 200);
            int obstacle5Width = randy.Next(10, 1000);

            obstacle5.Location = new Point(obstacle5.Location.X - 10, obstacle5.Location.Y);
            if (obstacle5.Location.X < -700)
            {
                obstacle5.Height = obstacle5Height;
                obstacle5.Width = obstacle5Width;

                obstacle5.Location = new Point(this.Width, obstacle5.Location.Y);

            }
        }
        private void Obstacle6Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle6Height = randy.Next(this.Width - 1000, this.Width - 100);
            int obstacle6Width = randy.Next(10, 1000);

            obstacle6.Location = new Point(obstacle6.Location.X - 10, obstacle6.Location.Y);
            if (obstacle6.Location.X < -700)
            {
                obstacle6.Height = obstacle6Height;
                obstacle6.Width = obstacle6Width;

                obstacle6.Location = new Point(this.Width, obstacle6.Location.Y);

            }
        }
        private void Obstacle7Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle7Height = randy.Next(this.Width - 1200, this.Width - 200);
            int obstacle7Width = randy.Next(10, 1000);

            obstacle7.Location = new Point(obstacle7.Location.X - 10, obstacle7.Location.Y);
            if (obstacle7.Location.X < -700)
            {
                obstacle7.Height = obstacle7Height;
                obstacle7.Width = obstacle7Width;

                obstacle7.Location = new Point(this.Width, obstacle7.Location.Y);

            }
        }
        private void Obstacle8Mover_Tick(object sender, EventArgs e)
        {//moves obstacle across screen, once reaches end then it regenerates at other side, with random size
            int obstacle8Height = randy.Next(this.Width - 1400, this.Width - 100);
            int obstacle8Width = randy.Next(10, 1000);

            obstacle8.Location = new Point(obstacle8.Location.X - 10, obstacle8.Location.Y);
            if (obstacle8.Location.X < -700)
            {
                obstacle8.Height = obstacle8Height;
                obstacle8.Width = obstacle8Width;

                obstacle8.Location = new Point(this.Width, obstacle8.Location.Y);

            }
        }


        private void EnemyShipMover_Tick(object sender, EventArgs e)
        {//moves enemy ship and enemy ship's firing picture across screen, at which point it respawns at the other side, at a random height
            int respawn = randy.Next(1, 400);
            EnemyShip.Location = new Point(EnemyShip.Location.X - 5, EnemyShip.Location.Y);
            if (EnemyShip.Location.X < -500)
            {
                EnemyShip.Location = new Point(this.Width + 400, respawn);
            }
            EnemyShipFiring.Location = new Point(EnemyShip.Location.X - 150, EnemyShip.Location.Y + 100);
        }
        private void EnemyShotMover_Tick(object sender, EventArgs e)
        {//moves enemy shot across screen, once it reaches end then it regenerates at enemy ship position
            EnemyShipShot.Location = new Point(EnemyShipShot.Location.X - 70, EnemyShipShot.Location.Y);
            if (EnemyShipShot.Location.X < -100)
            {
                EnemyShipShot.Location = new Point(EnemyShip.Location.X - 170, EnemyShipFiring.Location.Y);
            }
        }

        private void EnemyShip2Mover_Tick(object sender, EventArgs e)
        {//moves enemy ship and enemy ship's firing picture across screen, at which point it respawns at the other side, at a random height
            int respawn = randy.Next(1, 400);
            EnemyShip2.Location = new Point(EnemyShip2.Location.X - 5, EnemyShip2.Location.Y);
            if (EnemyShip2.Location.X < -500)
            {
                EnemyShip2.Location = new Point(this.Width + 400, respawn);
            }
            EnemyShip2Firing.Location = new Point(EnemyShip2.Location.X - 150, EnemyShip2.Location.Y + 100);
        }
        private void EnemyShot2Mover_Tick(object sender, EventArgs e)
        {//moves enemy shot across screen, once it reaches end then it regenerates at enemy ship position
            EnemyShip2Shot.Location = new Point(EnemyShip2Shot.Location.X - 70, EnemyShip2Shot.Location.Y);
            if (EnemyShip2Shot.Location.X < -100)
            {
                EnemyShip2Shot.Location = new Point(EnemyShip2.Location.X - 170, EnemyShip2Firing.Location.Y);
            }
        }

        private void EnemyShip3Mover_Tick(object sender, EventArgs e)
        {//moves enemy ship and enemy ship's firing picture across screen, at which point it respawns at the other side, at a random height
            int respawn = randy.Next(1, 400);
            EnemyShip3.Location = new Point(EnemyShip3.Location.X - 5, EnemyShip3.Location.Y);
            if (EnemyShip3.Location.X < -500)
            {
                EnemyShip3.Location = new Point(this.Width + 400, respawn);
            }
            EnemyShip3Firing.Location = new Point(EnemyShip3.Location.X - 150, EnemyShip3.Location.Y + 100);
        }
        private void EnemyShot3Mover_Tick(object sender, EventArgs e)
        {//moves enemy shot across screen, once it reaches end then it regenerates at enemy ship position
            EnemyShip3Shot.Location = new Point(EnemyShip3Shot.Location.X - 70, EnemyShip3Shot.Location.Y);
            if (EnemyShip3Shot.Location.X < -100)
            {
                EnemyShip3Shot.Location = new Point(EnemyShip3.Location.X - 170, EnemyShip3Firing.Location.Y);
            }
        }


        private void LaserMoveToUserPosition_Tick(object sender, EventArgs e)
        { //moves user shot (laser) across screen, at which point it respawns at user ship location
            UserShipLaser.Location = new Point(UserShipLaser.Location.X + 70, UserShipLaser.Location.Y);
            if (UserShipLaser.Location.X > this.Width)
            {
                UserShipLaser.Location = new Point(UserShip.Location.X + 460, UserShip.Location.Y + 59);
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {// if user clicks return to main screen label, close game form
            this.Close();
        }

        private void Collisions_Tick(object sender, EventArgs e) //timer for all collisions
        {
            
            if (UserShip.Bounds.IntersectsWith(EnemyShipShot.Bounds) || UserShip.Bounds.IntersectsWith(EnemyShip2Shot.Bounds) || UserShip.Bounds.IntersectsWith(EnemyShip3Shot.Bounds))
            {//if user is hit by any of the enemy ship's shots, then user loses health
                userHealth -= 10;

            }
            if (UserShip.Bounds.IntersectsWith(obstacle.Bounds) || UserShip.Bounds.IntersectsWith(obstacle2.Bounds) || UserShip.Bounds.IntersectsWith(obstacle3.Bounds) || UserShip.Bounds.IntersectsWith(obstacle4.Bounds))
            {//if user is hit by any of the obstacles (moving structures on ground)
                //user loses health
                userHealth -= 1;
            }
            if (UserShip.Bounds.IntersectsWith(obstacle5.Bounds) || UserShip.Bounds.IntersectsWith(obstacle6.Bounds) || UserShip.Bounds.IntersectsWith(obstacle7.Bounds) || UserShip.Bounds.IntersectsWith(obstacle8.Bounds))
            {//if user is hit by any of the obstacles (moving structures on ground), split into two if statements for neatness
                //user loses health
                userHealth -= 1;
            }
            if (UserShip.Bounds.IntersectsWith(Ground.Bounds))
            {//if user touches ground, user loses health
                userHealth -= 1;
            }

            if (userHealth <= 0) // if user runs completely out of health 
            {
                spUser.Play(); //play wilhelm scream

                //freeze all parts of game in place by disabling the timers that control the moving pieces
                EnemyShipMover.Enabled = false;
                EnemyShip2Mover.Enabled = false;
                EnemyShip3Mover.Enabled = false;
                EnemyShotMover.Enabled = false;
                EnemyShot2Mover.Enabled = false;
                EnemyShot3Mover.Enabled = false;
                ObstacleMover.Enabled = false;
                Obstacle2Mover.Enabled = false;
                Obstacle3Mover.Enabled = false;
                Obstacle4Mover.Enabled = false;
                Obstacle5Mover.Enabled = false;
                Obstacle6Mover.Enabled = false;
                Obstacle7Mover.Enabled = false;
                Obstacle8Mover.Enabled = false;
                LaserMoveToUserPosition.Enabled = false;

                //collisions is disable so that if the user dies and a shot is still touching the user, then the displayed health will not continue to decrease
                Collisions.Enabled = false;

                //move end of game message to be visible to user, with final score
                EndTitle.Location = new Point(300, 300);
                EndTitleTitle.Location = new Point(300, 270);
                LblReturn.Location = new Point(300, 500);
                EndTitle.Text = (userScore).ToString();

            }


            if (UserShipLaser.Bounds.IntersectsWith(EnemyShip.Bounds))
            {//if enemy ship is hit by user shot, then the enemy ship loses health
                enemyShipHealth -= 5;
                userScore += 10;
            }
            if (enemyShipHealth <=0)
            {//if enemy ship completely runs out of health, then play explosion sound effect and respawn the enemy ship back at the other side, at a random height
             // add to user kill count
                spEnemy.Play();
                int respawn = randy.Next(1, 400);
                EnemyShip.Location = new Point(this.Width + 400, respawn);
                enemyShipHealth = 50;
                userScore += 20;
                killCount++;
            }
            if (UserShipLaser.Bounds.IntersectsWith(EnemyShip2.Bounds))
            {//if enemy ship is hit by user shot, then the enemy ship loses health
                enemyShip2Health -= 5;
                userScore += 10;
            }
            if (enemyShip2Health <= 0)
            {//if enemy ship completely runs out of health, then play explosion sound effect and respawn the enemy ship back at the other side, at a random height
             // add to user kill count
                spEnemy.Play();
                int respawn = randy.Next(1, 400);
                EnemyShip2.Location = new Point(this.Width + 400, respawn);
                enemyShip2Health = 50;
                userScore += 20;
                killCount++;
            }
            if (UserShipLaser.Bounds.IntersectsWith(EnemyShip3.Bounds))
            {//if enemy ship is hit by user shot, then the enemy ship loses health
                enemyShip3Health -= 5;
                userScore += 10;
            }
            if (enemyShip3Health <= 0)
            {//if enemy ship completely runs out of health, then play explosion sound effect and respawn the enemy ship back at the other side, at a random height
             // add to user kill count
                spEnemy.Play();
                int respawn = randy.Next(1, 400);
                EnemyShip3.Location = new Point(this.Width + 400, respawn);
                enemyShip3Health = 50;
                userScore += 20;
                killCount++;
            }

            //updates user's score, health, and kill count on labels on screen
            LblUserScore.Text = (userScore).ToString();
            LblUserHealth.Text = (userHealth).ToString();
            LblKillCount.Text = (killCount).ToString();
            
            
        }

        


        //if I get rid of these it may mess up the game
        private void FrmGame_Load(object sender, EventArgs e)
        {

        }

        private void obstacle_Click(object sender, EventArgs e)
        {

        }

        private void LblUserScore_Click(object sender, EventArgs e)
        {

        }

        
    }
}
