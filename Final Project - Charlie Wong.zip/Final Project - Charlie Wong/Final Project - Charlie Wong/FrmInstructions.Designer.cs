﻿namespace Final_Project___Charlie_Wong
{
    partial class FrmInstructions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnInstructionsExit = new System.Windows.Forms.Button();
            this.lblInstructionsMove = new System.Windows.Forms.Label();
            this.lblInstructionsShoot = new System.Windows.Forms.Label();
            this.lblInstructionsTitle = new System.Windows.Forms.Label();
            this.LaserMoveToUserPosition = new System.Windows.Forms.Timer(this.components);
            this.lblOtherInstructions = new System.Windows.Forms.Label();
            this.UserShipLaser = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.UserShipLaser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnInstructionsExit
            // 
            this.btnInstructionsExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnInstructionsExit.Enabled = false;
            this.btnInstructionsExit.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstructionsExit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnInstructionsExit.Location = new System.Drawing.Point(472, 538);
            this.btnInstructionsExit.Name = "btnInstructionsExit";
            this.btnInstructionsExit.Size = new System.Drawing.Size(237, 46);
            this.btnInstructionsExit.TabIndex = 0;
            this.btnInstructionsExit.Text = "Return to main screen";
            this.btnInstructionsExit.UseVisualStyleBackColor = false;
            this.btnInstructionsExit.Click += new System.EventHandler(this.btnInstructionsExit_Click);
            this.btnInstructionsExit.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmInstructions_KeyDown);
            // 
            // lblInstructionsMove
            // 
            this.lblInstructionsMove.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructionsMove.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblInstructionsMove.Location = new System.Drawing.Point(12, 112);
            this.lblInstructionsMove.Name = "lblInstructionsMove";
            this.lblInstructionsMove.Size = new System.Drawing.Size(715, 37);
            this.lblInstructionsMove.TabIndex = 1;
            this.lblInstructionsMove.Text = "To move the spaceship around the screen, use the arrow keys.\r\n";
            // 
            // lblInstructionsShoot
            // 
            this.lblInstructionsShoot.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructionsShoot.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblInstructionsShoot.Location = new System.Drawing.Point(12, 168);
            this.lblInstructionsShoot.Name = "lblInstructionsShoot";
            this.lblInstructionsShoot.Size = new System.Drawing.Size(681, 51);
            this.lblInstructionsShoot.TabIndex = 2;
            this.lblInstructionsShoot.Text = "The spaceship will shoot at the enemy automatically.";
            // 
            // lblInstructionsTitle
            // 
            this.lblInstructionsTitle.AutoSize = true;
            this.lblInstructionsTitle.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructionsTitle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblInstructionsTitle.Location = new System.Drawing.Point(385, 9);
            this.lblInstructionsTitle.Name = "lblInstructionsTitle";
            this.lblInstructionsTitle.Size = new System.Drawing.Size(412, 90);
            this.lblInstructionsTitle.TabIndex = 3;
            this.lblInstructionsTitle.Text = "Instructions";
            // 
            // LaserMoveToUserPosition
            // 
            this.LaserMoveToUserPosition.Enabled = true;
            this.LaserMoveToUserPosition.Interval = 10;
            this.LaserMoveToUserPosition.Tick += new System.EventHandler(this.LaserMoveToUserPosition_Tick);
            // 
            // lblOtherInstructions
            // 
            this.lblOtherInstructions.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOtherInstructions.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lblOtherInstructions.Location = new System.Drawing.Point(711, 112);
            this.lblOtherInstructions.Name = "lblOtherInstructions";
            this.lblOtherInstructions.Size = new System.Drawing.Size(640, 96);
            this.lblOtherInstructions.TabIndex = 7;
            this.lblOtherInstructions.Text = "The goal is to destroy as many enemy ships as possible. But don\'t get hit by thei" +
    "r shots! If you touch the mountains below or are hit by the enemies\' shots, then" +
    " you will lose health.";
            // 
            // UserShipLaser
            // 
            this.UserShipLaser.Image = global::Final_Project___Charlie_Wong.Properties.Resources.UserShipLaser;
            this.UserShipLaser.Location = new System.Drawing.Point(354, 363);
            this.UserShipLaser.Name = "UserShipLaser";
            this.UserShipLaser.Size = new System.Drawing.Size(545, 54);
            this.UserShipLaser.TabIndex = 6;
            this.UserShipLaser.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Final_Project___Charlie_Wong.Properties.Resources.Capture;
            this.pictureBox2.Location = new System.Drawing.Point(472, 538);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 46);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // FrmInstructions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1415, 644);
            this.Controls.Add(this.lblOtherInstructions);
            this.Controls.Add(this.UserShipLaser);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblInstructionsTitle);
            this.Controls.Add(this.lblInstructionsShoot);
            this.Controls.Add(this.lblInstructionsMove);
            this.Controls.Add(this.btnInstructionsExit);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "FrmInstructions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Instructions";
            this.Load += new System.EventHandler(this.FrmInstructions_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FrmInstructions_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmInstructions_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.UserShipLaser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstructionsExit;
        private System.Windows.Forms.Label lblInstructionsMove;
        private System.Windows.Forms.Label lblInstructionsShoot;
        private System.Windows.Forms.Label lblInstructionsTitle;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox UserShipLaser;
        private System.Windows.Forms.Timer LaserMoveToUserPosition;
        private System.Windows.Forms.Label lblOtherInstructions;
    }
}