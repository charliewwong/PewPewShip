﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project___Charlie_Wong
{
    public partial class FrmInstructions : Form
    {
        //image data        
        Image imgUserShip = Properties.Resources.UserShip1;
        Image imgUserShot = Properties.Resources.UserShipShot1;
        //ints for user position
        int curX = 50;
        int curY = 210;

        //bounding rectangle
        Rectangle rctUserShip;

        public FrmInstructions()
        {
            //generating bounding rectangles, setting location of user ship's laser
            InitializeComponent();
            rctUserShip = new Rectangle(curX, curY, imgUserShip.Width, imgUserShip.Height);

            UserShipLaser.Location = new Point(curX + 380, curY + 38);
        }

        private void FrmInstructions_KeyDown(object sender, KeyEventArgs e)
        {
            //user controls, moving ship up, down, left, and right
            switch (e.KeyCode)
            {
                case Keys.Up:
                    curY -= 15;
                    break;
                case Keys.Down:
                    curY += 15;
                    break;
                case Keys.Left:
                    curX -= 10;
                    break;
                case Keys.Right:
                    curX += 20;
                    break;

            }

             this.Invalidate();
        }

        private void FrmInstructions_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Draw user ship and user shot
            g.DrawImage(imgUserShip, curX, curY);
            g.DrawImage(imgUserShot, curX + 300, curY + 48);
        }

        private void LaserMoveToUserPosition_Tick(object sender, EventArgs e)
        {
            //shooting user's laser - moves across screen to a certain point, where it regenerates at the user's position
            UserShipLaser.Location = new Point(UserShipLaser.Location.X + 40, UserShipLaser.Location.Y);
            if (UserShipLaser.Location.X > this.Width)
            {
                UserShipLaser.Location = new Point(curX + 380, curY + 38);
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {// if exit button is pressed, close instructions form
            this.Close();
        }



        //if I get rid of these it may mess up the game
        private void btnInstructionsExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void pictureBox1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            

        }
        private void FrmInstructions_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

    }
}
