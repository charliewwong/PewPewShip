﻿namespace Final_Project___Charlie_Wong
{
    partial class FrmTitleScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnPlay = new System.Windows.Forms.Button();
            this.BtnInstructions = new System.Windows.Forms.Button();
            this.BtnTitleExit = new System.Windows.Forms.Button();
            this.BtnMoreGames = new System.Windows.Forms.Button();
            this.TitleMoveThing = new System.Windows.Forms.Timer(this.components);
            this.MusicTitle = new System.Windows.Forms.Label();
            this.EnemyShipMover = new System.Windows.Forms.Timer(this.components);
            this.EnemyShip = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnPlay
            // 
            this.BtnPlay.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BtnPlay.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPlay.Location = new System.Drawing.Point(424, 176);
            this.BtnPlay.Name = "BtnPlay";
            this.BtnPlay.Size = new System.Drawing.Size(97, 50);
            this.BtnPlay.TabIndex = 0;
            this.BtnPlay.Text = "Play!";
            this.BtnPlay.UseVisualStyleBackColor = false;
            this.BtnPlay.Click += new System.EventHandler(this.BtnPlay_Click);
            // 
            // BtnInstructions
            // 
            this.BtnInstructions.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BtnInstructions.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInstructions.Location = new System.Drawing.Point(378, 259);
            this.BtnInstructions.Name = "BtnInstructions";
            this.BtnInstructions.Size = new System.Drawing.Size(190, 59);
            this.BtnInstructions.TabIndex = 1;
            this.BtnInstructions.Text = "Instructions";
            this.BtnInstructions.UseVisualStyleBackColor = false;
            this.BtnInstructions.Click += new System.EventHandler(this.BtnInstructions_Click);
            // 
            // BtnTitleExit
            // 
            this.BtnTitleExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BtnTitleExit.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnTitleExit.Location = new System.Drawing.Point(424, 349);
            this.BtnTitleExit.Name = "BtnTitleExit";
            this.BtnTitleExit.Size = new System.Drawing.Size(97, 49);
            this.BtnTitleExit.TabIndex = 2;
            this.BtnTitleExit.Text = "Exit";
            this.BtnTitleExit.UseVisualStyleBackColor = false;
            this.BtnTitleExit.Click += new System.EventHandler(this.BtnTitleExit_Click);
            // 
            // BtnMoreGames
            // 
            this.BtnMoreGames.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.BtnMoreGames.Location = new System.Drawing.Point(409, 465);
            this.BtnMoreGames.Name = "BtnMoreGames";
            this.BtnMoreGames.Size = new System.Drawing.Size(123, 38);
            this.BtnMoreGames.TabIndex = 3;
            this.BtnMoreGames.Text = "More games by this developer...";
            this.BtnMoreGames.UseVisualStyleBackColor = false;
            this.BtnMoreGames.Click += new System.EventHandler(this.BtnMoreGames_Click);
            // 
            // TitleMoveThing
            // 
            this.TitleMoveThing.Tick += new System.EventHandler(this.TitleMoveThing_Tick);
            // 
            // MusicTitle
            // 
            this.MusicTitle.AutoSize = true;
            this.MusicTitle.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MusicTitle.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MusicTitle.Location = new System.Drawing.Point(27, 465);
            this.MusicTitle.Name = "MusicTitle";
            this.MusicTitle.Size = new System.Drawing.Size(98, 23);
            this.MusicTitle.TabIndex = 4;
            this.MusicTitle.Text = "Music from:";
            // 
            // EnemyShipMover
            // 
            this.EnemyShipMover.Enabled = true;
            this.EnemyShipMover.Interval = 50;
            this.EnemyShipMover.Tick += new System.EventHandler(this.EnemyShipMover_Tick);
            // 
            // EnemyShip
            // 
            this.EnemyShip.BackColor = System.Drawing.Color.Transparent;
            this.EnemyShip.Image = global::Final_Project___Charlie_Wong.Properties.Resources.EnemyShip1;
            this.EnemyShip.Location = new System.Drawing.Point(683, 44);
            this.EnemyShip.Name = "EnemyShip";
            this.EnemyShip.Size = new System.Drawing.Size(240, 141);
            this.EnemyShip.TabIndex = 5;
            this.EnemyShip.TabStop = false;
            // 
            // FrmTitleScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(982, 527);
            this.Controls.Add(this.EnemyShip);
            this.Controls.Add(this.MusicTitle);
            this.Controls.Add(this.BtnMoreGames);
            this.Controls.Add(this.BtnTitleExit);
            this.Controls.Add(this.BtnInstructions);
            this.Controls.Add(this.BtnPlay);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "FrmTitleScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Welcome!";
            this.Load += new System.EventHandler(this.FrmTitleScreen_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FrmTitleScreen_Paint);
            ((System.ComponentModel.ISupportInitialize)(this.EnemyShip)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnPlay;
        private System.Windows.Forms.Button BtnInstructions;
        private System.Windows.Forms.Button BtnTitleExit;
        private System.Windows.Forms.Button BtnMoreGames;
        private System.Windows.Forms.Timer TitleMoveThing;
        private System.Windows.Forms.Label MusicTitle;
        private System.Windows.Forms.Timer EnemyShipMover;
        private System.Windows.Forms.PictureBox EnemyShip;
    }
}

