﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using WMPLib;


namespace Final_Project___Charlie_Wong
{
    public partial class FrmTitleScreen : Form
    {
        //Image Data
        Image TitleLogo = Properties.Resources.TitleLogo1;
        Image VulfpeckLogo = Properties.Resources.VulfLogo;

        //Bounding Rectangles
        Rectangle rctTitleLogo;
        Rectangle rctVulfpeckLogo;

        //random
        Random randy = new Random();

        //to play music
        WindowsMediaPlayer wmpMusic = new WindowsMediaPlayer();

        
        public FrmTitleScreen()
        {
            InitializeComponent();

            //Set up bounding rectangles, object positions
            rctTitleLogo = new Rectangle(140, 50, TitleLogo.Width, TitleLogo.Height);
            rctVulfpeckLogo = new Rectangle(120, 450, 50, 50);

            EnemyShip.Location = new Point(this.Width, 50);

            //play music
            MusicTitle.Location = new Point(16, 460);
            wmpMusic.URL = "Resources\\SkyMall.mp3";
            wmpMusic.controls.play();
            wmpMusic.settings.playCount = 100;

        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            //opening up game form when play button is clicked
            FrmGame Game = new FrmGame();
            Game.ShowDialog();
            this.Show();


        }

        private void BtnInstructions_Click(object sender, EventArgs e)
        {
            //opening up instructions form when button is clicked
            this.Hide();
            FrmInstructions Instructions = new FrmInstructions();
            Instructions.ShowDialog();
            this.Show();
        }

        private void BtnTitleExit_Click(object sender, EventArgs e)
        {
            //closing program when exit button is clicked
            Application.Exit();
        }

        private void BtnMoreGames_Click(object sender, EventArgs e)
        {
            //message when button is clicked
            MessageBox.Show("There are currently no other games.");
        }

        private void FrmTitleScreen_Paint(object sender, PaintEventArgs e)
        {
            
            Graphics g = e.Graphics;

            //drawing title, music credits
            g.DrawImage(TitleLogo,rctTitleLogo);
            g.DrawImage(VulfpeckLogo, rctVulfpeckLogo);

        }

        private void EnemyShipMover_Tick(object sender, EventArgs e)
        {
            //moving enemy ship across screen, when it reaches end it respawns back on the other side, at a random point
            int respawn = randy.Next(1, this.Height);
            EnemyShip.Location = new Point(EnemyShip.Location.X - 5, EnemyShip.Location.Y);
            if (EnemyShip.Location.X < -500)
            {
                EnemyShip.Location = new Point(this.Width, respawn);
            }
        }




        //if I get rid of these it may mess up the game
        private void FrmTitleScreen_Load(object sender, EventArgs e)
        {

        }
        private void TitleMoveThing_Tick(object sender, EventArgs e)
        {
        }

        
    }
}
